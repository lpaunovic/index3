<?php
$ime = "Lazar";
$prezime = "Paunovic";
$index = "18s";

echo "Ime: $ime <br>";
echo "Prezime: $prezime <br>";
echo "Broj Indeksa: $index";
?>