from flask import Flask, render_template, redirect, url_for, request, session
from pymongo import MongoClient
from flask_uploads import UploadSet, IMAGES, configure_uploads
from bson import ObjectId
import datetime	
import hashlib
import time

app = Flask(__name__)
photos = UploadSet('photos', IMAGES)
app.config['UPLOADED_PHOTOS_DEST'] = 'static'
configure_uploads(app, photos)
app.config['SECRET_KEY'] = 'NEKI RANDOM STRING'
client = MongoClient("mongodb+srv://lazar:Lazarko123@cluster0-hohvr.mongodb.net/test?retryWrites=true&w=majority")
db = client.get_database("db_domaci7_8")

users = db["users"]
proizvodi = db["proizvodi"]

@app.route('/')
@app.route('/index')
def index():
	p = list(proizvodi.find())
	korisnik = {}
	korisnik['type'] = "test"
	if '_id' in session:
		korisnik = users.find_one({"_id": ObjectId(session["_id"])})
		return render_template('index.html',proizvodi = p,korisnik = korisnik,korisnici = users.find())
	return render_template('index.html',proizvodi=p,korisnik = korisnik,korisnici = users.find())



@app.route('/registracija',methods = ["POST","GET"])
def registracija():
	if request.method == 'GET':
		return render_template('registracija.html')
		
	if users.find_one({"username": request.form['username']}) is not None:
		return 'Username vec postoji!'
	username = request.form["username"]
	email = request.form["email"]
	password1 = request.form["password1"]
	password2 = request.form["password2"]
	pol = request.form["pol"]
	godina = request.form["godina"]
	tip_korisnika = request.form["usertype"]
	if password1 != password2:
		return "Sifre se ne poklapaju!"

	hash_object = hashlib.sha256(request.form['password1'].encode())
	password_hashed = hash_object.hexdigest()	
	if 'slika' in request.files:
			photos.save(request.files['slika'], 'img', request.form['username'] + '.png')
	naziv_slike = request.form["username"] + ".png"
	unos = {
		"username":username,
		"email":email,
		"password":password_hashed,
		'created': time.strftime("%d-%m-%Y.%H:%M:%S"),
		"pol": pol,
		"godina": godina,
		"type": tip_korisnika,
		'slika': "/static/img/" + naziv_slike
	}
	users.insert_one(unos)
	return redirect(url_for('index'))



@app.route('/dodaj_proizvod',methods = ["POST","GET"])
def dodaj_proizvod():
	if session["type"] != "prodavac":
		return redirect(url_for('login'))
	if request.method == "GET":
		return render_template("dodaj_proizvod.html")
	naziv = request.form["naziv"]
	if 'slika' in request.files:
			photos.save(request.files['slika'], 'img', request.form['naziv'] + '.png')
	cena = request.form['cena']
	kolicina = request.form['kolicina']
	naziv_slike = request.form["naziv"] + ".png"
	p = {
		'cena':cena,
		"naziv":naziv,
		'kolicina': kolicina,
		"prodavac": str(session['_id']),
		'slika': "/static/img/" + naziv_slike
		
	}
	proizvodi.insert_one(p)
	return redirect(url_for('index'))



@app.route('/<id>/update_user',methods = ["POST","GET"])
def update_user(id):
	
	if request.method == "GET":
		k = users.find_one({"_id": ObjectId(id)})
		if k == None:
			return "Korisnik ne posotji."
		return render_template("update_user.html",korisnik = k)

	email = request.form["email"] # request.form["name iz forme"] dohvatamo vrednost polja
	pol = request.form["pol"]
	godina = request.form["godina"]
	usertype = request.form["usertype"]
	new_user = {
		"email":email,
		"pol":pol,
		"godina":godina,
		"type":usertype
	}
	users.update_one({"_id":ObjectId(id)},{"$set": new_user})
	return redirect(url_for('index'))



@app.route('/<id>/delete_user')
def delete_user(id):
	k = users.find_one({"_id": ObjectId(id)})
	if k == None:
		return "Korisnik ne postoji!"
	users.delete_one({"_id":ObjectId(id)})
	return redirect(url_for("index"))



@app.route('/<id>/update_item',methods = ["POST","GET"])
def update_item(id):
	
	if request.method == "GET":
		p = proizvodi.find_one({"_id": ObjectId(id)})
		if p == None:
			return "Proizvod ne posotji."
		return render_template("update_item.html",proizvod = p)

	naziv = request.form["naziv"] # request.form["name iz forme"] dohvatamo vrednost polja
	cena = request.form["cena"]
	kolicina = request.form["kolicina"]
	new_item = {
		"naziv":naziv,
		"cena":cena,
		"kolicina":kolicina,
	}
	proizvodi.update_one({"_id":ObjectId(id)},{"$set": new_item})
	return redirect(url_for('index'))



@app.route('/<id>/delete_item')
def delete_item(id):
	p = proizvodi.find_one({"_id": ObjectId(id)})
	if p == None:
		return "Proizvod ne postoji!"
	proizvodi.delete_one({"_id":ObjectId(id)})
	return redirect(url_for("index"))


@app.route('/login', methods = ['GET', 'POST'])
def login():
	if '_id' in session:
		return "Vec ste ulogovani"
	if request.method == 'GET':
		return render_template('login.html')
	else:
		hash_object = hashlib.sha256(request.form['password'].encode())
		password_hashed = hash_object.hexdigest()
		user = users.find_one({'username':request.form['username'], 'password':password_hashed})
		if user is None:
			return 'Pogresan username ili password!'
		session['_id'] = str(user['_id'])
		session['type'] = user['type']
		return redirect(url_for("index"))


@app.route('/logout')
def logout():
	if "_id" in session:
		session.pop('_id',None)
		session.pop('type')
		return redirect(url_for('index'))
	return redirect(url_for('index'))


@app.route('/clear')
def clear():
	session.clear()
	return redirect(url_for('index'))		
	

if __name__ == '__main__':
	app.run()